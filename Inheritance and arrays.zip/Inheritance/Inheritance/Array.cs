﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
   class Array
   {
      Texture2D textureArray;
      Rectangle rectangleArray;
      
       
   public Array (Texture2D newtextureArray,Rectangle newrectangleArray)
   {
      textureArray = newtextureArray;
      rectangleArray = newrectangleArray;

   }
      public void Draw(SpriteBatch spriteBatch)
   {
      spriteBatch.Draw(textureArray, rectangleArray, Color.White);
   }
}
}