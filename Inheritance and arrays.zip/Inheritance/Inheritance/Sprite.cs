﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
   class Sprite
   {
      public Texture2D texture;
      public Rectangle rectangle;
      Array tile;
        
      public virtual void Update()
      {

      }
      public void Draw( SpriteBatch spriteBatch)
      {
         
         spriteBatch.Draw(texture,rectangle,Color.White);
         
      }
   }
   // make this the child class of Sprite class
   class Character: Sprite
   {
      public Character (Texture2D newTexture, Rectangle newRectangle)
      {
         texture=newTexture;
         rectangle=newRectangle;
    
        
         
      }
      
      public override void Update()
      {
       
         if (Keyboard.GetState().IsKeyDown(Keys.Right))
            rectangle.X += 5; { if (rectangle.X + texture.Width > 800) rectangle.X = 800 - texture.Width; }
         if (Keyboard.GetState().IsKeyDown(Keys.Down))
            rectangle.Y += 5; { if (rectangle.Y + texture.Height > 500) rectangle.Y = 500 - texture.Height; }
        
        
         if (Keyboard.GetState().IsKeyDown(Keys.Left))
            rectangle.X -= 5; { if (rectangle.X <= 0) rectangle.X = 0; }

         if (Keyboard.GetState().IsKeyDown(Keys.Up))
            rectangle.Y -= 5; { if (rectangle.Y <= 0) rectangle.Y = 0; }
        
         
        
           
        
      }

   }
}
